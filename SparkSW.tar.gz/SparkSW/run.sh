#!/bin/bash
# an example to run sparksw  
sh test.sh 2G hash50.csv query.file db.file 32 1 3
