#!/bin/bash

#sbt clean
#sbt package

mem=$1
subMatrixFile=$2
queryFile=$3
dbFile=$4
splitNum=$5
taskNum=$6
topK=$7

#/home/zgg/lib/spark-1.0.1-bin-hadoop2/bin/spark-submit \
/path/to/spark-submit \
  --class "SparkSW" \
  --master spark://192.168.1.7:7077 \
  --executor-memory $mem \
  target/scala-2.10/sparksw-project_2.10-1.0.jar $subMatrixFile $queryFile $dbFile $splitNum $taskNum $topK 
